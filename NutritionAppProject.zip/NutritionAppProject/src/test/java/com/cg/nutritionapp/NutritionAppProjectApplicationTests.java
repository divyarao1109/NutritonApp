package com.cg.nutritionapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutritionAppProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
