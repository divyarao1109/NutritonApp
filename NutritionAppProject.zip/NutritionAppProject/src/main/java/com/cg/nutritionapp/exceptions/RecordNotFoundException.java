package com.cg.nutritionapp.exceptions;

public class RecordNotFoundException extends RuntimeException {
	public RecordNotFoundException(String s) {
		super(s);
	}

}
