package com.cg.nutritionapp.exceptions;

public class NoChoiceException extends Exception {
public NoChoiceException() {
	super();
}
public NoChoiceException(String errMsg) {
	super(errMsg);
}

}
