package com.cg.nutritionapp.exceptions;

public class DietPlanException extends Exception {

	public DietPlanException(String message)
	{
		super(message);
	}
}
