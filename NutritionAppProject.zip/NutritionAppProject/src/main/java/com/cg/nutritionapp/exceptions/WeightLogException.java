package com.cg.nutritionapp.exceptions;

public class WeightLogException extends Exception{
	private static final long serialVersionUID = 1L;
	public WeightLogException() {
		super();		
	}
	public WeightLogException(String message) {
		super(message);
	}
	

}