package com.cg.nutritionapp.exceptions;

public class ValidateUserException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ValidateUserException() {
		super();		
	}
	public ValidateUserException(String message) {
		super(message);
	}

}
