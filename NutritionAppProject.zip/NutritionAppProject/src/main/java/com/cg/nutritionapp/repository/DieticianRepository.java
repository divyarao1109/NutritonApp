package com.cg.nutritionapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.nutritionapp.model.Dietician;

public interface DieticianRepository extends CrudRepository<Dietician,Integer> {

}
