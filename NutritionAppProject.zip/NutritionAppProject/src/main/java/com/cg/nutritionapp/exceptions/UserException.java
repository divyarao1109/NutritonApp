package com.cg.nutritionapp.exceptions;

/**
 * A customised Exception class for UserExceprion
 * @author 
 *
 */
public class UserException extends Exception {

	public UserException(String string) {
		super(string);
	}
	

}
